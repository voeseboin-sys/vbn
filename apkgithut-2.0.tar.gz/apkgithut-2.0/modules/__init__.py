"""
Módulos de la aplicación Gestión Fábrica
Repositorio: voeseboin-sys/apkgithut
"""
from .pdf_generator import PDFGenerator, generar_y_compartir_pdf

__all__ = ['PDFGenerator', 'generar_y_compartir_pdf']
